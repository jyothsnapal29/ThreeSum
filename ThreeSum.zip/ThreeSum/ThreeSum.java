public class ThreeSum
{
	pubic List<List<Integer>> getThreeSum(int[] nums)
	{
		List<List<Integer>> result = new List<List<Integer>>();
		
		if(nums == null || nums.length < 3)
		{
			return result;
		}
		
		int n = nums.length()
		
		Arrays.sort()
		
		for(int i = 0; i < n - 2 ; i++)
		{
			if(nums[i] == 0 || nums[i] < nums[i -1])
			{
				j = i + 1;
				k = n - 1;
				
				while(j < k)
				{
					if(nums[i] + nums[j] + nums[k] == 0)
					{
						List<Integer> l = new List<Integer>();
						l.add(nums[i]);
						l.add(nums[j]);
						l.add(nums[k]);
						result.add(l);
					
					
						j++;
						k--;
						
						//Handling duplicates
						while(j < k && nums[j] == nums[j-1])
						{
							j++;
						}
						
						while(j < k && nums[k] == nums[k+1])
						{
							k--;
						}	
					}
					else if(nums[i] + nums[j] + nums[k] < 0)
					{
						j++;
					}
					else
					{
						k--;
					}
				}
			}
		}
		return result;
	}
	
	public static void main(String[] args)
	{
		ThreeSum threeSum = new ThreeSum();
		int nums[] = {-1, 2, 1, 0, 3};
		List<List<Integer>> result = threeSum.getThreeSum();
		for(List<String> res : result)
        {
            //dumb logic to place the commas correctly
            if(!csv.isEmpty())
            {
                
                for(int i=0; i < res.size(); i++)
                {
                    System.out.print("," + res.get(i));
                }
            }
            System.out.print("\n");
        }
	}
}